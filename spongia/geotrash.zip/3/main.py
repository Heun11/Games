from code import GameApp
# run app
if __name__ == "__main__":
    GameApp().run()